package tests.gui;

import models.TestCaseLombok;
import models.TestCaseLombokBuilder;
import org.testng.annotations.Test;

import java.util.List;

public class LombokTest1 {

    @Test
    public void firstTest() {
        TestCaseLombok testCaseLombok = new TestCaseLombok();
        testCaseLombok.setTitle("Test Title");
        String title = testCaseLombok.getTitle();

        System.out.println(title);
        System.out.println(testCaseLombok.toString());
        System.out.println(testCaseLombok.hashCode());
        System.out.println(testCaseLombok.equals(testCaseLombok));
    }

    @Test
    public void secondTest() {
        TestCaseLombokBuilder testCaseLombokBuilder = TestCaseLombokBuilder.builder()
                .title("Test Title")
                .reference("Link 1")
                .reference("Link 2")
                .reference("Link 3")
                .build();

        String title = testCaseLombokBuilder.getTitle();

        System.out.println(title);
        System.out.println(testCaseLombokBuilder.getEstimate());
        System.out.println(testCaseLombokBuilder.toString());
        System.out.println(testCaseLombokBuilder.getReferences().size());
        System.out.println(testCaseLombokBuilder.getReferences().get(0));
        System.out.println(testCaseLombokBuilder.hashCode());
        System.out.println(testCaseLombokBuilder.equals(testCaseLombokBuilder));
    }
}
