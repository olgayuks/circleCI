package tests.gui;

import baseEntities.BaseTest;
import models.*;
import org.testng.annotations.Test;
import steps.AdministrationStep;
import steps.LoginSteps;

public class PageFactoryTest extends BaseTest {

    @Test
    public void firstTest() {
        User user = new User(readProperties.getUsername(), readProperties.getPassword());

        LoginSteps loginSteps = new LoginSteps(driver);
        loginSteps.login(user);

        Project project = new Project("Main Project", "Какое описание", true, 1, false );

        ProjectBuilder projectBuilder = new ProjectBuilder.Builder()
                .withName("")
                .withAnnouncement("")
                .build();

        Account account = Account.newBuilder()
                .setToken("hello")
                .setUserId("habr")
                .build();

        AdministrationStep administrationStep = new AdministrationStep();
        administrationStep.updateProject(project);
    }

    @Test
    public void secondTest() {
        TestCase testCase = new TestCase.Builder()
                .withTitle("Title 1")
                .withReference("AQA-1")
                .build();

        testCase.getTitle();
    }
}
