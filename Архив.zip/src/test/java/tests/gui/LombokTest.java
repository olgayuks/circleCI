package tests.gui;

import baseEntities.BaseTest;
import models.ProjectBuilderLombok;
import models.ProjectBuilderLombokBuilder;
import org.testng.annotations.Test;

public class LombokTest extends BaseTest {

    @Test
    public void firstTest() {
        ProjectBuilderLombok projectBuilderLombok = new ProjectBuilderLombok();
        projectBuilderLombok.setName("asdasd");

        try {
            int i = 10 / 0;
        } catch (Exception ex) {
        }
    }

    @Test
    public void secondTest() {
        ProjectBuilderLombokBuilder projectBuilderLombokBuilder = ProjectBuilderLombokBuilder.builder()
                .name("dsdf")
                .isCompleted(true)
                .build();

        projectBuilderLombokBuilder.getAnnouncement();
    }
}
