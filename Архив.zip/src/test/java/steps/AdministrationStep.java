package steps;

import models.Project;

public class AdministrationStep {

    public void updateProject(Project project) {
        //ToDo: implement this method
        //setNewName(project.getName());
    }
}
