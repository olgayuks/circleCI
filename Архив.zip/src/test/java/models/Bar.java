package models;

public class Bar {
//    private static final Logger logger = LogManager.getLogger(Bar.class);

    public boolean doIt() {
        return true;
    }
/*
        logger.entry();
        logger.error("Did it again!");
        return logger.exit(false);
    }
*/
}
