package models;

public class Endpoints {
    public static String addProject = "/index.php?/api/v2/add_project";
}
