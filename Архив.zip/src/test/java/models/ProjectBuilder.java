package models;

public class ProjectBuilder {
    private String name;
    private String announcement;
    private boolean isShowAnnouncement;
    private int typeOfProject;
    private boolean isCompleted;

    public static class Builder {
        private ProjectBuilder projectBuilder;

        public Builder() {
            projectBuilder = new ProjectBuilder();
        }

        public Builder withName(String name) {
            projectBuilder.name = name;

            return this;
        }

        public Builder withAnnouncement(String announcement) {
            projectBuilder.announcement = announcement;

            return this;
        }

        public ProjectBuilder build() {
            return projectBuilder;
        }
    }
}