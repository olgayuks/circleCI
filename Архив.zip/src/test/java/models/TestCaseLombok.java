package models;


import lombok.Data;

@Data
public class TestCaseLombok {
    //1. Описание private переменных которые нам будут нужны для этой сушности
    private String title;
    private int estimate;
    private String reference;
}
