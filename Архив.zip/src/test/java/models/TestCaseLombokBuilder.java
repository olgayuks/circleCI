package models;

import lombok.*;

import java.util.List;

@Getter
@Builder
public class TestCaseLombokBuilder {
    //1. Описание private переменных которые нам будут нужны для этой сушности
    @NonNull
    private String title;
    @Builder.Default
    private int estimate = 5;
    @Singular
    private List<String> references;
}
