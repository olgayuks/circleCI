package models;

import com.sun.istack.internal.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder()
public class ProjectBuilderLombokBuilder {
    @NotNull
    private String name;
    private String announcement;
    private boolean isShowAnnouncement;
    private int typeOfProject;
    private boolean isCompleted;
}