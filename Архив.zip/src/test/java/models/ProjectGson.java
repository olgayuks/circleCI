package models;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@Builder
public class ProjectGson {
    @EqualsAndHashCode.Exclude
    int id;
    String name;
    String announcement;
    boolean show_announcement;
    boolean is_completed;
    String completed_on;
    int suite_mode;
    @EqualsAndHashCode.Exclude
    String url;
}
