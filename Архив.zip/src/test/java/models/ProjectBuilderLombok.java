package models;

import lombok.Data;

@Data
public class ProjectBuilderLombok {
    private String name;
    private String announcement;
    private boolean isShowAnnouncement;
    private int typeOfProject;
    private boolean isCompleted;
}